const LIST = [
    {
        id: 1,
        nome: 'Mestre Yoda',
        imagem: 'images/yoda.png'
    },
    {
        id: 2,
        nome: 'Darth Vader',
        imagem: 'images/vader.png'
    },
    {
        id: 3,
        nome: 'R2-D2',
        imagem: 'images/r2d2.png'
    },
    {
        id: 4,
        nome: 'Luke Skywalker',
        imagem: 'images/luke.png'
    },
    {
        id: 5,
        nome: 'Princesa Leia',
        imagem: 'images/leia.png'
    },
    {
        id: 6,
        nome: 'Han Solo',
        imagem: 'images/hansolo.png'
    },
    {
        id: 7,
        nome: 'Chewbacca',
        imagem: 'images/chewbacca.png'
    },
    {
        id: 8,
        nome: 'C-3PO',
        imagem: 'images/c3po.png'

    }
];

const App = new Vue({
    el: '#app',
    data: {
        title: 'Star Wars Lego',
        userName: 'Gabriela Ventura',
        characters: LIST,
        searchName: ''
    },
    methods: {
        like(userName){
            alert(`O personagem ${userName} foi curtido!`);
        },
        remove(id){
            this.characters = this.characters.filter(item => {
                return item.id !== id;
            });
        },
    search() {

            if (this.searchName === ''){
                return alert('O campo de busca é obrigatório.')
            }

             const list = this.characters = LIST

             const result = list.filter(item => {
            return item.nome === this.searchName
            })

            if (result.length <= 0){
            alert('Nenhum personagem encontrado!')
            }
        
             else {
             this.characters = result
             }
        
        }
    }
})